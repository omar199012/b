from telegram import (
    Update,
)

from telegram.ext import (
    ContextTypes,
)

import tweepy

from dotenv import load_dotenv
import os


async def twitter_post(update:Update, context:ContextTypes.DEFAULT_TYPE):
    if not context.bot_data['platforms']['twitter']:
        context.bot_data['platforms']['twitter'] = True
        await update.callback_query.answer(text='X(Twitter) selected!', show_alert=True)
    else:
        context.bot_data['platforms']['twitter'] = False
        await update.callback_query.answer(text='X(Twitter) cancelled!', show_alert=True)


async def post_on_twitter(ayat:str, context:ContextTypes.DEFAULT_TYPE):
    load_dotenv()
    
    client = tweepy.Client(bearer_token=os.getenv("TWITTER_BEARER_TOKEN"))

    client = tweepy.Client(consumer_key=os.getenv("TWITTER_CONSUMER_KEY"),
                           consumer_secret=os.getenv("TWITTER_CONSUMER_SECRET"),
                           access_token=os.getenv("TWITTER_ACCESS_TOKEN"),
                           access_token_secret=os.getenv("TWITTER_ACCESS_TOKEN_SECRET"))
    
    client.create_tweet(text=ayat)
    print("Posted on Twitter!")

