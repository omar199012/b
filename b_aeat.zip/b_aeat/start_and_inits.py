from telegram import (
    Bot,
    BotCommand,
    Update
)
from telegram.ext import (
    Application,
    ContextTypes
)

async def inits(app:Application):
    bot: Bot = app.bot

    await bot.set_my_commands([BotCommand('start','to start the bot'),
                               BotCommand('post_settings','to choose where to post')])


async def start(update:Update, context:ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id in (5652465292,):
        if not context.bot_data.get('platforms', None):
            context.bot_data['platforms'] = {'facebook':False,
                                            'instagram':False,
                                            'twitter':False,
                                            'telegram':False}
            
            await update.message.reply_text(text="ًأهلا بك، اضغط على /post_settings لاختيار المنصات التي تريد النشر عليها.")
            return
        
        await update.message.reply_text(text="أهلاً مجدداً، اضغط على /post_settings لاختيار المنصات التي تريد النشر عليها")
    
    
