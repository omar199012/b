from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ConversationHandler,
    PicklePersistence
)

import datetime

from dotenv import load_dotenv
import os

from post_job import post_job
from start_and_inits import start, inits
from facebook import facebook_post
from instagram import instagram_post
from twitter import twitter_post
from telegram_channel import telegram_post
from post_settings import choose_platforms, on_done, on_back_from_chosen, on_no_done, on_show_chosen, on_yes_done
from sharing import on_share_here, on_share_somewhere_else

def main():
    load_dotenv()

    #initiating the application with persistence
    my_persistence = PicklePersistence(filepath="data")
    app = (Application.builder()
           .token(os.getenv("BOT_TOKEN"))
           .persistence(persistence=my_persistence)
           .post_init(inits)
           .concurrent_updates(True)
           .build())
    
    app.add_handler(CommandHandler('start', start))

    #POST CONVERSATION
    app.add_handler(ConversationHandler(entry_points=[CommandHandler('post_settings', choose_platforms)],
                                        states={
                                            1:[CallbackQueryHandler(facebook_post, 'facebook post'),
                                               CallbackQueryHandler(instagram_post, 'instagram post'),
                                               CallbackQueryHandler(twitter_post, 'twitter post'),
                                               CallbackQueryHandler(telegram_post, 'telegram channel post'),
                                               CallbackQueryHandler(on_done, 'done'),
                                               CallbackQueryHandler(on_show_chosen, 'show chosen')],
                                            2:[CallbackQueryHandler(on_no_done, 'no'),
                                               CallbackQueryHandler(on_yes_done,'yes')],
                                        },
                                        fallbacks= [CallbackQueryHandler(on_back_from_chosen, 'back from show chosen')]))
    
    #SHARING
    app.add_handler(CallbackQueryHandler(on_share_here, 'share here'))
    app.add_handler(CallbackQueryHandler(on_share_somewhere_else, 'share somewhere else'))
    
    #JOB
    tz = datetime.timezone(datetime.timedelta(hours=+3))
    eight_AM = datetime.time(9,20,tzinfo=tz)
    eight_PM = datetime.time(18,20,tzinfo=tz)

    job_queue = app.job_queue
    job_queue.run_daily(post_job, eight_AM)
    job_queue.run_daily(post_job, eight_PM)

    app.run_polling()